window.__PRODUCTION__QIAOQIAOYUN__CONF__ = {
    VITE_GLOB_APP_TITLE: "敲敲云",
    VITE_GLOB_APP_SHORT_NAME: "qiaoqiaoyun",
    VITE_GLOB_APP_CAS_BASE_URL: "http://cas.test.com:8443/cas",
    VITE_GLOB_APP_OPEN_SSO: "false",
    VITE_GLOB_APP_OPEN_QIANKUN: "true",
    VITE_GLOB_ONLINE_VIEW_URL: "http://fileview.jeecg.com/onlinePreview",
    VITE_GLOB_API_URL: "/qiaoqiaoyun",
    VITE_GLOB_DOMAIN_URL: "/qiaoqiaoyun",
    VITE_GLOB_API_URL_PREFIX: "",
};
Object.freeze(window.__PRODUCTION__QIAOQIAOYUN__CONF__);
Object.defineProperty(window, "__PRODUCTION__QIAOQIAOYUN__CONF__", {
    configurable: false,
    writable: false,
});
